import type { PwaOptions } from '@vite-pwa/vitepress';
import type { HeadConfig } from 'vitepress';

import { resolve } from 'node:path';

import {
  injectCssLayerOrder,
  THIRD_PARTY_CSS_LAYER_RULES,
  viteArchiverPlugin,
  viteCssLayerPlugin,
  viteDayjsPlugin,
  viteVxeTableImportsPlugin,
} from '@vben/vite-config';

import {
  GitChangelog,
  GitChangelogMarkdownSection,
} from '@nolebase/vitepress-plugin-git-changelog/vite';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig, postcssIsolateStyles } from 'vitepress';
import {
  groupIconMdPlugin,
  groupIconVitePlugin,
} from 'vitepress-plugin-group-icons';

import { demoPreviewPlugin } from './plugins/demo-preview';
import { search as zhSearch } from './zh.mts';

export const shared = defineConfig({
  appearance: 'dark',
  head: head(),
  markdown: {
    preConfig(md) {
      md.use(demoPreviewPlugin);
      md.use(groupIconMdPlugin);
    },
    // VitePress 2 alpha 会把 code fence 套两层，导致两个复制按钮；只拆掉重复外壳。
    config(md) {
      const fence = md.renderer.rules.fence;
      if (!fence) return;
      md.renderer.rules.fence = (...args) =>
        unwrapDuplicateCodeFence(fence(...args));
    },
  },
  pwa: pwa(),
  srcDir: 'src',
  themeConfig: {
    i18nRouting: true,
    logo: 'https://unpkg.com/@vbenjs/static-source@0.1.7/source/logo-v1.webp',
    search: {
      options: {
        locales: {
          ...zhSearch,
        },
      },
      provider: 'local',
    },
    siteTitle: 'Vben Admin',
    socialLinks: [
      { icon: 'github', link: 'https://github.com/vbenjs/vue-vben-admin' },
    ],
  },
  title: 'Vben Admin',
  // VitePress 构建自行生成 HTML，需在其构建钩子中补上最前置的层序声明。
  transformHtml: injectCssLayerOrder,
  vite: {
    build: {
      chunkSizeWarningLimit: Infinity,
      minify: 'terser',
    },
    css: {
      postcss: {
        plugins: [postcssIsolateStyles({ includeFiles: [/vp-doc\.css/] })],
      },
      preprocessorOptions: {
        scss: {
          // api: 'modern',
        },
      },
    },
    json: {
      stringify: true,
    },
    plugins: [
      viteDayjsPlugin(),
      tailwindcss(),
      // 第三方库样式（vxe / tippy.js / vue-json-pretty）包入 vxe / lib 层，
      // 使 Tailwind 工具类可覆盖；层序声明见 @vben/tailwind-config 的 theme.css
      viteCssLayerPlugin(THIRD_PARTY_CSS_LAYER_RULES),
      GitChangelog({
        mapAuthors: [
          {
            mapByNameAliases: ['Vben'],
            name: 'vben',
            username: 'anncwb',
          },
          {
            name: 'vince',
            username: 'vince292007',
          },
          {
            name: 'Li Kui',
            username: 'likui628',
          },
          {
            mapByNameAliases: ['Jin Mao', 'jinmao'],
            name: 'Jin Mao',
            username: 'jinmao88',
          },
          {
            name: 'Netfan',
            username: 'mynetfan',
          },
          {
            mapByNameAliases: ['xingyu4j', 'xingyu'],
            name: 'xingyu4j',
            username: 'xingyu4j',
          },
        ],
        repoURL: () => 'https://github.com/vbenjs/vue-vben-admin',
      }) as any,
      GitChangelogMarkdownSection(),
      viteArchiverPlugin({ outputDir: '.vitepress' }),
      groupIconVitePlugin(),
      await viteVxeTableImportsPlugin(),
    ],
    server: {
      fs: {
        allow: ['../..'],
      },
      host: true,
      port: 6173,
    },

    ssr: {
      external: ['@vue/repl'],
      noExternal: ['@v-c/picker'],
    },
  },
});

function head(): HeadConfig[] {
  return [
    ['meta', { content: 'Vbenjs Team', name: 'author' }],
    [
      'meta',
      {
        content: 'vben, vitejs, vite, shadcn-ui, vue',
        name: 'keywords',
      },
    ],
    ['link', { href: '/favicon.ico', rel: 'icon', type: 'image/svg+xml' }],
    [
      'meta',
      {
        content:
          'width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no',
        name: 'viewport',
      },
    ],
    ['meta', { content: 'vben admin docs', name: 'keywords' }],
    ['link', { href: '/favicon.ico', rel: 'icon' }],
    // [
    //   'script',
    //   {
    //     src: 'https://cdn.tailwindcss.com',
    //   },
    // ],
  ];
}

function pwa(): PwaOptions {
  return {
    includeManifestIcons: false,
    manifest: {
      description:
        'Vben Admin is a modern admin dashboard template based on Vue 3. ',
      icons: [
        {
          sizes: '192x192',
          src: 'https://unpkg.com/@vbenjs/static-source@0.1.7/source/pwa-icon-192.png',
          type: 'image/png',
        },
        {
          sizes: '512x512',
          src: 'https://unpkg.com/@vbenjs/static-source@0.1.7/source/pwa-icon-512.png',
          type: 'image/png',
        },
      ],
      id: '/',
      name: 'Vben Admin Doc',
      short_name: 'vben_admin_doc',
      theme_color: '#ffffff',
    },
    outDir: resolve(process.cwd(), '.vitepress/dist'),
    registerType: 'autoUpdate',
    workbox: {
      globPatterns: ['**/*.{css,js,html,svg,png,ico,txt,woff2}'],
      maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
    },
  };
}

function unwrapDuplicateCodeFence(html: string): string {
  const nested = html.match(
    /^<div class="language-[^"]*"><button[^>]*\sclass="copy"[^>]*><\/button><span class="lang">[^<]*<\/span>(<div class="language-[^"]*"[\s\S]*)<\/div>\s*$/,
  );
  return nested?.[1] ?? html;
}
